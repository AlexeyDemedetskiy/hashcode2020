//
//  Solver.h
//  Solver
//
//  Created by Alexey Demedetskii on 2/8/20.
//  Copyright © 2020 Genesis. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Solver.
FOUNDATION_EXPORT double SolverVersionNumber;

//! Project version string for Solver.
FOUNDATION_EXPORT const unsigned char SolverVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Solver/PublicHeader.h>



//
//  ScorerTests.swift
//  SolverTests
//
//  Created by Alexey Demedetskii on 2/8/20.
//  Copyright © 2020 Genesis. All rights reserved.
//

import XCTest
@testable import Solver

class ScorerTests: XCTestCase {
    func testTrivial() throws {
        let problem = Problem(
            maximumNumberOfSlices: 17,
            pizzas: [
                Pizza(numberOfSlices: 2),
                Pizza(numberOfSlices: 5),
                Pizza(numberOfSlices: 6),
                Pizza(numberOfSlices: 8)
        ])
        
        let solution = Solution(
            indices: [0, 2, 3]
        )
        
        let correctScore = 16 as UInt64
        
        let actualScore = try Scorer.score(for: problem, with: solution)
        
        XCTAssertEqual(correctScore, actualScore)
    }
}

